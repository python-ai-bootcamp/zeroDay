# Assignment 1: ✍️
<p></p>

# Evaluation Content:

<h3> you will be evaluated on the following content</h3>
<br/>
<ul>
  <li>➤ Environment Setup</li>
  <li>➤ python text data methods</li>
  <li>➤ python functions</li>
</ul>



# Instructions
<br/>
<ol type="1">
<li>
    Download the Assignment by using the Command (check your downloads directory)
</li>
<br/>
<li>
    Unzip assignment zip file and open directory in IDE (VS-Code)
</li>
<br/>
<li>
    Complete the Assignment by completing each python file
    <ul>
        <li>•    `a1_task1.py`</li>
        <li>•    `a1_task2.py`</li>
        <li>•    `a1_task3.py`</li>
    </ul>
</li>
<br/>
<li>instructions are written in the file under #TODO heading</li>
<li> run files locally using command `python ai_task<task_number>.py`</li>
<li>All output files should be saved into default assignment directory</li>
<br/>
<li>Submit the assignment by command scp </li>
</ol>

# Rules
<br/>
<ul>
<br/>
<li>➤ 1. Applicants may use any resource for reference </li>
<br/>
<li>➤ 2. All Assignments that are submitted must be written entirely by applicatant</li>
<ul>
    <li>•    2.1. Applicant may not copy paste from internet or online LLM</li>
    <li>•    2.2. Strict anti-cheating measures are applied, please don't test this</li>
</ul>
<br/>
<li>➤ 3. All assignments must be submitted in the same format as the example</li>
</ul>




